package com.example.popcornmanager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private Spinner spinnerSpecials;
    CheckBox cbBaconValid;
    CheckBox cbCheeseValid;
    CheckBox cbButterValid;
    TextView tvPopCornNameIsValid;
    RadioButton rbSpecialValid;
    RadioButton rbNormalValid;
    Spinner spSpecials;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        spinnerSpecials=findViewById(R.id.spinnerSpecials);
        populateSpinner();
        cbCheeseValid= findViewById(R.id.cBCheese);
        cbButterValid= findViewById(R.id.cBButter);
        rbSpecialValid =findViewById(R.id.rBSpecial);
        rbNormalValid =findViewById(R.id.rBNormal);
        tvPopCornNameIsValid= findViewById(R.id.eTPopCornName);
        spSpecials = findViewById(R.id.spinnerSpecials);
        cbBaconValid=findViewById(R.id.cBBacon);
    }

    public void populateSpinner(){
        List<String> spinnerList = new ArrayList<>();
        spinnerList.add("powered milk");
        spinnerList.add("chocolate");
        spinnerList.add("canned milk");
        spinnerList.add("banoffee");

        ArrayAdapter<String> adapter=
                new ArrayAdapter<>(this
                , android.R.layout.simple_list_item_1,
                        spinnerList);
        spinnerSpecials.setAdapter(adapter);
    }

    public void showPopulatedSpinner(View view){
        confirmAlldata(view);
    }

    public boolean isValidName(){
        if(tvPopCornNameIsValid.getText().length()==0){
            return false;
        }
        return true;
    }

    public boolean isValidIngredient(){
        if(!cbBaconValid.isChecked() &&
                !cbCheeseValid.isChecked() &&
                !cbButterValid.isChecked()){
            return false;
        }
        return true;
    }

    public boolean isValidType(){
        if(!rbSpecialValid.isChecked() &&
                !rbNormalValid.isChecked()){
            return false;
        }
        return true;
    }

    public void confirmAlldata(View view){
        String message="";
        if(!isValidName()){
            message="Please write a PopCorn name";
            tvPopCornNameIsValid.requestFocus();
        } else if (!isValidIngredient()){
            message="Please select one ingredient";
        } else if (!isValidType()) {
            message="Please select one Type";
        } else {
            message="Saving on Database";

        }
        Toast.makeText(this,
                message,
                Toast.LENGTH_LONG).show();
    }

    public void cleanAll(View view){
        tvPopCornNameIsValid.setText("");
        cbBaconValid.setChecked(false);
        cbButterValid.setChecked(false);
        cbCheeseValid.setChecked(false);
        rbNormalValid.setChecked(false);
        rbSpecialValid.setChecked(false);
    }

    public void selectSpecial(View view){
        if(rbSpecialValid.isChecked()){
            rbNormalValid.setChecked(false);
        }
    }

    public void selectNormal(View view){
        if(rbNormalValid.isChecked()){
            rbSpecialValid.setChecked(false);
        }
    }

}