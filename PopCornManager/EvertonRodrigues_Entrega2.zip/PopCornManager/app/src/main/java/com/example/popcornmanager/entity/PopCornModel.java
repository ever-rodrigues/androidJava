package com.example.popcornmanager.entity;

public class PopCornModel extends AbstractModel{
    private String popCornType;

    public PopCornModel(String id, String popCornName, int price,String popCornType) {
        super(id,popCornName, price);
        this.popCornType=popCornType;
    }

    public String getPopCornType() {
        return popCornType;
    }

    public void setPopCornType(String popCornType) {
        this.popCornType = popCornType;
    }
}
