package com.example.popcornmanager;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.example.popcornmanager.adapters.PopCornAdapter;
import com.example.popcornmanager.entity.PopCornModel;

import java.util.ArrayList;

public class PopCornListViewActivity extends AppCompatActivity {

    private ListView listViewPopCornNames;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pop_corn_list_view);

        listViewPopCornNames= findViewById(R.id.lVName);

        listViewPopCornNames.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent,
                                    View view,
                                    int position,
                                    long id){
                PopCornModel popCornModel=(PopCornModel) listViewPopCornNames.getItemAtPosition(position);

                Toast.makeText(PopCornListViewActivity.this,
                        popCornModel.getPopCornName()+" clicked", Toast.LENGTH_SHORT).show();
            }
        });
        populatePopCornList();
    }

    private void populatePopCornList(){
        ArrayList<PopCornModel> myPopCornList = new ArrayList<>();

        String[] popCornIds =getResources().getStringArray(R.array.popCornIds);
        String[] popCornNames =getResources().getStringArray(R.array.popCornNames);
        int[] popCornPrices = getResources().getIntArray(R.array.popCornPrices);
        String[] popCornTypes =getResources().getStringArray(R.array.popCornTypes);

        for(int cont=0;cont<popCornNames.length;cont++){
            myPopCornList.add(new PopCornModel(popCornIds[cont], popCornNames[cont],popCornPrices[cont],popCornTypes[cont]));
        }

        PopCornAdapter popCornAdapter= new PopCornAdapter(this,myPopCornList);
        listViewPopCornNames.setAdapter(popCornAdapter);

//        ArrayAdapter<PopCornModel> adapter=
//                new ArrayAdapter(this,
//                android.R.layout.simple_list_item_1,
//                   myPopCornList);
//        listViewPopCornNames.setAdapter(adapter);

    }
}