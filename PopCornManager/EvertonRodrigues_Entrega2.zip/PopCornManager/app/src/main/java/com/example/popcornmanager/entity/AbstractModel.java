package com.example.popcornmanager.entity;

public abstract class AbstractModel {

    private String id;
    private String popCornName;
    private int price;

    public AbstractModel() {
    }

    public AbstractModel(String id,String popCornName, Integer price) {
        this.popCornName = popCornName;
        this.price = price;
        this.id=id;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPopCornName() {
        return popCornName;
    }

    public void setPopCornName(String popCornName) {
        this.popCornName = popCornName;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

}
